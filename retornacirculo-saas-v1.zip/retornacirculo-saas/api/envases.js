import { createClient } from '@supabase/supabase-js';
import QRCode from 'qrcode';

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SECRET_KEY
);

function generarQRCode(empresaId, material, contador) {
  const ts = Date.now().toString(36).toUpperCase();
  const num = String(contador).padStart(8, '0');
  return `QR-ENV-CL-${num}-${ts}`;
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();

  // ── GET /api/envases → listar envases ──────────────────────────
  if (req.method === 'GET') {
    const { empresa_id, material, estado, limit = 20, offset = 0 } = req.query;
    let query = supabase.from('envases').select(`
      *,
      empresas ( razon_social, rut )
    `).order('registrado_en', { ascending: false }).range(offset, offset + limit - 1);

    if (empresa_id) query = query.eq('empresa_id', empresa_id);
    if (material)   query = query.eq('material', material);
    if (estado)     query = query.eq('estado', estado);

    const { data, error, count } = await query;
    if (error) return res.status(500).json({ error: error.message });
    return res.status(200).json({ data, count, limit, offset });
  }

  // ── POST /api/envases → registrar nuevo envase ─────────────────
  if (req.method === 'POST') {
    const { empresa_id, material, peso_kg, capacidad_l, lote } = req.body;

    // Validaciones
    if (!empresa_id || !material || !peso_kg) {
      return res.status(400).json({ error: 'empresa_id, material y peso_kg son obligatorios' });
    }
    const materialesValidos = ['PET','VIDRIO','CARTON','METAL','PLASTICO_RIGIDO','OTRO'];
    if (!materialesValidos.includes(material)) {
      return res.status(400).json({ error: `Material inválido. Válidos: ${materialesValidos.join(', ')}` });
    }

    // Verificar que la empresa existe
    const { data: empresa, error: empError } = await supabase
      .from('empresas').select('id, razon_social').eq('id', empresa_id).single();
    if (empError || !empresa) {
      return res.status(404).json({ error: 'Empresa no encontrada' });
    }

    // Contar envases existentes para generar número correlativo
    const { count } = await supabase.from('envases').select('*', { count: 'exact', head: true });
    const qr_code = generarQRCode(empresa_id, material, (count || 0) + 1);

    // Insertar envase
    const { data: envase, error: envError } = await supabase
      .from('envases')
      .insert([{ empresa_id, material, peso_kg, capacidad_l, lote, qr_code, estado: 'EN_CAMPO' }])
      .select().single();

    if (envError) return res.status(500).json({ error: envError.message });

    // Registrar evento REGISTRO
    await supabase.from('eventos').insert([{
      envase_id: envase.id,
      tipo_evento: 'REGISTRO',
      operador: 'API_REGISTRO',
      metadata: { empresa: empresa.razon_social, material, lote }
    }]);

    // Generar QR como imagen base64
    let qr_imagen = null;
    try {
      qr_imagen = await QRCode.toDataURL(qr_code, {
        width: 300, margin: 2,
        color: { dark: '#0a0a0a', light: '#ffffff' }
      });
    } catch (e) { /* QR opcional */ }

    return res.status(201).json({
      success: true,
      envase,
      qr_imagen,
      mensaje: `Envase registrado exitosamente en ${empresa.razon_social}`
    });
  }

  return res.status(405).json({ error: 'Método no permitido' });
}
