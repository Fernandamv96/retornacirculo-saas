import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SECRET_KEY
);

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();

  if (req.method === 'GET') {
    const { data, error } = await supabase
      .from('empresas').select('*').eq('activa', true).order('razon_social');
    if (error) return res.status(500).json({ error: error.message });
    return res.status(200).json({ data });
  }

  if (req.method === 'POST') {
    const { rut, razon_social, tipo, region, retc_codigo, sig_id } = req.body;
    if (!rut || !razon_social || !tipo || !region) {
      return res.status(400).json({ error: 'rut, razon_social, tipo y region son obligatorios' });
    }
    const { data, error } = await supabase
      .from('empresas').insert([{ rut, razon_social, tipo, region, retc_codigo, sig_id }])
      .select().single();
    if (error) return res.status(500).json({ error: error.message });
    return res.status(201).json({ success: true, empresa: data });
  }

  return res.status(405).json({ error: 'Método no permitido' });
}
