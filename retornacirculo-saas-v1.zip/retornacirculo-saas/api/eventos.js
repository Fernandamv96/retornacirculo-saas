import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SECRET_KEY
);

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();

  // ── GET /api/eventos?qr_code=xxx → historial de un envase ──────
  if (req.method === 'GET') {
    const { qr_code, envase_id } = req.query;
    if (!qr_code && !envase_id) {
      return res.status(400).json({ error: 'Se requiere qr_code o envase_id' });
    }

    let eid = envase_id;
    if (qr_code) {
      const { data: env } = await supabase
        .from('envases').select('id,qr_code,material,peso_kg,estado,empresa_id, empresas(razon_social)')
        .eq('qr_code', qr_code).single();
      if (!env) return res.status(404).json({ error: `QR ${qr_code} no encontrado` });
      eid = env.id;

      const { data: eventos } = await supabase
        .from('eventos').select('*')
        .eq('envase_id', eid).order('ocurrido_en', { ascending: true });

      return res.status(200).json({ envase: env, eventos: eventos || [] });
    }

    const { data: eventos } = await supabase
      .from('eventos').select('*')
      .eq('envase_id', eid).order('ocurrido_en', { ascending: true });

    return res.status(200).json({ eventos: eventos || [] });
  }

  // ── POST /api/eventos → registrar retorno / evento ─────────────
  if (req.method === 'POST') {
    const { qr_code, tipo_evento, peso_real_kg, punto_id, operador, lat, lng, metadata } = req.body;

    if (!qr_code || !tipo_evento) {
      return res.status(400).json({ error: 'qr_code y tipo_evento son obligatorios' });
    }

    // Buscar envase por QR
    const { data: envase } = await supabase
      .from('envases').select('*').eq('qr_code', qr_code).single();
    if (!envase) return res.status(404).json({ error: `QR ${qr_code} no encontrado` });

    // Validar transición de estado
    const transiciones = {
      'EN_CAMPO':    ['DESPACHO','ESCANEO_QR','RETORNO_OK','RETORNO_CONTAMINADO','RECHAZADO_PESO'],
      'EN_TRANSITO': ['RECEPCION','RETORNO_OK','RETORNO_CONTAMINADO','RECHAZADO_PESO'],
      'RETORNADO':   ['EN_TRANSITO','VALORIZADO'],
      'VALORIZADO':  ['REPORTADO_RETC'],
      'RECHAZADO':   []
    };
    const permitidos = transiciones[envase.estado] || [];
    if (!permitidos.includes(tipo_evento) && tipo_evento !== 'ESCANEO_QR') {
      return res.status(409).json({
        error: `Transición no permitida: ${envase.estado} → ${tipo_evento}`,
        estado_actual: envase.estado,
        transiciones_permitidas: permitidos
      });
    }

    // Mapear tipo_evento a nuevo estado del envase
    const estadoMap = {
      'RETORNO_OK':           'RETORNADO',
      'RETORNO_CONTAMINADO':  'RETORNADO',
      'RECHAZADO_PESO':       'RECHAZADO',
      'VALORIZADO':           'VALORIZADO',
      'DESPACHO':             'EN_TRANSITO',
      'EN_TRANSITO':          'EN_TRANSITO',
      'RECEPCION':            'EN_CAMPO',
    };
    const nuevo_estado = estadoMap[tipo_evento] || envase.estado;

    // Validación de peso (±15%)
    let alerta_peso = null;
    if (peso_real_kg && envase.peso_kg) {
      const diff = Math.abs(peso_real_kg - envase.peso_kg) / envase.peso_kg * 100;
      if (diff > 15) alerta_peso = `Desviación de peso: ${diff.toFixed(1)}% (esperado: ${envase.peso_kg}kg, real: ${peso_real_kg}kg)`;
    }

    // Insertar evento
    const { data: evento, error: evError } = await supabase
      .from('eventos')
      .insert([{ envase_id: envase.id, tipo_evento, peso_real_kg, punto_id, operador: operador || 'API', lat, lng, metadata }])
      .select().single();

    if (evError) return res.status(500).json({ error: evError.message });

    // Actualizar estado del envase
    await supabase.from('envases')
      .update({ estado: nuevo_estado, actualizado_en: new Date().toISOString() })
      .eq('id', envase.id);

    return res.status(201).json({
      success: true,
      evento,
      envase_id: envase.id,
      qr_code,
      estado_anterior: envase.estado,
      estado_nuevo: nuevo_estado,
      alerta_peso,
      mensaje: `Evento ${tipo_evento} registrado exitosamente`
    });
  }

  return res.status(405).json({ error: 'Método no permitido' });
}
